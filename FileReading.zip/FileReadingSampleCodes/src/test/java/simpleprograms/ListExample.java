package simpleprograms;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ListExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stubt
		
		
		List li = new ArrayList();
		li.add("Suresh");
		li.add("Alex");
		li.add(2);
		li.add(34.44f);
		
		/*
		 * System.out.println(li.get(0)); 
		 * System.out.println(li.set(0, "Nazeer set"));
		 * System.out.println(li.size()); 
		 * System.out.println(li.contains(2));
		 * 
		 * System.out.println(li);
		 */
		
		ArrayList<Integer> list = new ArrayList();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(43);
		
		//list.clear();
		
		/*
		 * System.out.println(list.set(0, 55)); System.out.println(list);
		 * System.out.println(list.hashCode());
		 */
		
		ArrayList li2 = new ArrayList();
		
		System.out.println(li2);
		
		li2.addAll(list);
		li2.add("Nazeer");
		li2.add("Basheer");
		li2.addAll(li);
		System.out.println(li2);
		
		Object[] ToArray =li2.toArray();
		System.out.println("Converted to array " +ToArray);
		
		//System.out.println(li2);
		
		li2.add(0, "Johnny");
			
		
	   li2.addAll(0, li2);
	  // System.out.println(li2);
	   
	 // System.out.println(li.indexOf("Johnny"));
		
	   
	   LinkedList lnklst = new LinkedList();
	   
	   lnklst.add("A");
	   lnklst.add("B");
	   lnklst.add("C");
	   lnklst.add("C");
	   lnklst.add(12);
	   lnklst.add(1);
	   
	   System.out.println(lnklst);

	}

}
