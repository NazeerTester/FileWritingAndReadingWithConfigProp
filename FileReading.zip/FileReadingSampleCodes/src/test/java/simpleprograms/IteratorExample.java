package simpleprograms;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class IteratorExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		List<String> li = new ArrayList();
		li.add("BMW");
		li.add("Benz");
		li.add("volvo");
		System.out.println(li);
		
		Iterator<String> it =li.iterator();
		
		System.out.println(it.next());
		System.out.println(it.hasNext());
		
		ArrayList<String> lit = new ArrayList<String>();
		lit.add("John");
		lit.add("Jack");
		lit.add("Jamal");
		lit.add("Jose");
		
		Iterator<String> lists =lit.iterator();
		System.out.println(lists.next());
		
		
		

	}

}
