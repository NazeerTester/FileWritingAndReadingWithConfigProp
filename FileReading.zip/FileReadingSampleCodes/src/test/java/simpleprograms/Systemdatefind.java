package simpleprograms;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Systemdatefind {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SimpleDateFormat sim = new SimpleDateFormat();
		
		Date d = new Date();
		
		System.out.println(sim.format(d));
		

	}

}
