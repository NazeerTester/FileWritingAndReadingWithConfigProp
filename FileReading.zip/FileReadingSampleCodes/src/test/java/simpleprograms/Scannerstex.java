package simpleprograms;

import java.util.Scanner;


public class Scannerstex  {




	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Name");
		

		System.out.println(sc.next());
		//System.out.println(sc.nextLine());
		
		int a =sc.nextInt();
		
		int b = sc.nextInt();
		int c = a+b;
		System.out.println("C value is " +c);
		
		
		System.out.println(sc.hasNext());
		
	

	}

}
