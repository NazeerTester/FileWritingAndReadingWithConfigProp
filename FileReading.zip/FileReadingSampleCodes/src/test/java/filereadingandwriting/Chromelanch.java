package filereadingandwriting;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



public class Chromelanch {

	

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		WebDriver driver = null;

		FileInputStream file = new FileInputStream("config.properties");

		Properties prop = new Properties();
		prop.load(file);

		String browser =prop.getProperty("browser");
		String url = prop.getProperty("url");


		if(browser.equalsIgnoreCase("chrome")){
			try {
				driver = new ChromeDriver();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if (browser.equalsIgnoreCase("firefox")){
			System.setProperty("Webdriver.gecko.driver", "");
			driver = new FirefoxDriver();
		}
		
		driver.get(url);

	}
	
}




