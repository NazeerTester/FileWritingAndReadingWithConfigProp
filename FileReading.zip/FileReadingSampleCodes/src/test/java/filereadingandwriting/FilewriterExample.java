package filereadingandwriting;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FilewriterExample {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		String filename = "Buffytxt.txt";
		String content = "Nazeer is awesome";
		
		FileWriter files = new FileWriter(filename);
		BufferedWriter buffy = new BufferedWriter(files);
		
		buffy.write(content);
		
		buffy.close();
	

	}

}
