package filereadingandwriting;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;

public class BufferedreaderExample {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		String location = "Bufferedwriterfile.txt";
			FileReader file = new FileReader(location);
		
		BufferedReader buff = new BufferedReader(file);
		String lineread;
    
     			  while ((lineread =buff.readLine())!= null) 
		  { System.out.println(lineread); 
		  }
		

	}

}
