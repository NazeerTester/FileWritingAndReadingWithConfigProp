package filereadingandwriting;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FilereadingExample {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
	//	String content = "Awesome";
		String location = "Buffytxt.txt";
		
		FileReader fill = new FileReader(location);
		BufferedReader buffers = new BufferedReader(fill);
		
		String reading;
		
		while ((reading =buffers.readLine())!=null) {
			System.out.println(reading);
		}

	}

}
