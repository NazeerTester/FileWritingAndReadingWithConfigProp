package filereadingandwriting;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedWriterExample {
	
	//File can be read using FIlewriter or BufferedWriter
	//Buffferdwriter is easy and widely used for its performance

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		String location = "Bufferedwriterfile.txt";
		String content = "Writing something";
		
		FileWriter file = new FileWriter(location);
		
		BufferedWriter buff = new BufferedWriter(file);
		buff.write(content);
		
		buff.close();

	}

}
