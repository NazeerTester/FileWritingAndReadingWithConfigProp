package stringlearner;

public class Strip {

	
	public static void main(String[] args) {
		
		String fad = "   SPEED    is   good  @ # ^ ";
		
		System.out.println(fad);
		
		fad =fad.strip();
		
		System.out.println(fad);
		
		fad = fad.stripLeading();
		
		System.out.println(fad);
		
		fad = fad.stripTrailing();
		
		System.out.println(fad);
	}
}
