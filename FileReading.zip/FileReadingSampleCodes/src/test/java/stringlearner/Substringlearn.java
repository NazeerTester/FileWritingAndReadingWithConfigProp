package stringlearner;

public class Substringlearn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String star = "john great";
		
		System.out.println(star.substring(5, 10));

	}

}
