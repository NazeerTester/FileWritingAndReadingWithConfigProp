package train;

import java.util.Arrays;

public class Sortandarrayforascendingorder {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Source:https://www.javatpoint.com/how-to-sort-an-array-in-java

		//1.Sorting using sort method

		//create an array

		int [] array ={22,1,3,4,55,66};

		//using sort method sort it

		Arrays.sort(array);

		System.out.println("Elements of array are sorted in ascending");

		for(int i=0; i<array.length; i++) {

			System.out.println(array[i]);
		}



	}

}
