package train;

public class Removespaceinstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		// Using replaceAll method 
		
		String str = "Nazeer  is  AWESOME";
		
		System.out.println("Before removing the space " + str);
		
		str = str.replaceAll("  ", "");
		
		System.out.println("After removing the space " + str);
		
		// Using trim method
		
		String str2 = "Nazeer  is  AWESOME";
		
		str2 = str2.trim();
		System.out.println("used trim method to removing the space " + str);

	}

}
