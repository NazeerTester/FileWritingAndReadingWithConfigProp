package train;

public class Removespacewithtrim {

	public static void main(String[] args) {
		// TODO Auto-generated method stubt
		
		String str = "         Nazeer is Awesome   ";
		
		
		str = str.trim();
		
		System.out.println(str);
		
		String star = "    Nazeer   is   Awesome    ";
		star = star.replaceAll("   ", "");
		System.out.println(star);

	}

}
